File Name Hints:
- Sets R have customers location generated uniformly randomly over a square
- Sets C have clustered customers whose time windows were generated 
	based on a known solution
- Sets RC have a combination of randomly placed and clustered customers
- Sets of type 1 have narrow time windows and small vehicle capacity
- Sets of type 2 have large time windows and large vehicle capacity. 

Each excel data set contains depot information at the top of the file
Header information about the depot is displayed in the first line of the file
In the second line is the actual depot information

On line 3 there is a header containing information pertaining to the shipments
Begining on line 4, specific information about each shipment is listed

The file will end with the final line being the return trip to the depot