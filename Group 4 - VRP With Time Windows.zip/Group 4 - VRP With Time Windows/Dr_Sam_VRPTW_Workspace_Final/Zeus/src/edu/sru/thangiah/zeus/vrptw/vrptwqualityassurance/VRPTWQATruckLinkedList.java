package edu.sru.thangiah.zeus.vrptw.vrptwqualityassurance;

import edu.sru.thangiah.zeus.qualityassurance.*;

/**
 *
 * <p>Title:</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author Sam R. Thangiah
 * edit Aaron Weckerly
 * @version 2.0
 */
/**
 * Linked List of VRPTWQATrucks, extended from QATruckLinkedList
 * 
 */
public class VRPTWQATruckLinkedList
    extends QATruckLinkedList
    implements java.io.Serializable, java.lang.Cloneable {
	/**
	 * Linked list of VRPTWQATrucks
	 */
  public VRPTWQATruckLinkedList() {
  }
}
