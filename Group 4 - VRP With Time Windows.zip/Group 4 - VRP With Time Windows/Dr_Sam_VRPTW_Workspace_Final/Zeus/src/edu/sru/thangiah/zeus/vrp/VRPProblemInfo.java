package edu.sru.thangiah.zeus.vrp;

public class VRPProblemInfo {
  public VRPProblemInfo() {
  }
}
