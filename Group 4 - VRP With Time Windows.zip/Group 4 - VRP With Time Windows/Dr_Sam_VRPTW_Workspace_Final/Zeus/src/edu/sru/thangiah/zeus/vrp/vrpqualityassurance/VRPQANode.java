package edu.sru.thangiah.zeus.vrp.vrpqualityassurance;

import edu.sru.thangiah.zeus.qualityassurance.*;

/**
 *
 * <p>Title:</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author Sam R. Thangiah
 * @version 2.0
 */
/** @todo Need to document the variables and the parameters */
public class VRPQANode
    extends QANode
    implements java.io.Serializable, java.lang.Cloneable {
  public VRPQANode() {
  }
}
