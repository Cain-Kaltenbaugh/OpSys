package edu.sru.thangiah.zeus.vrptw.vrptwqualityassurance;

import edu.sru.thangiah.zeus.qualityassurance.*;

/**
 *
 * <p>Title:</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author Sam R. Thangiah
 * edit Aaron Weckerly
 * @version 2.0
 */
public class VRPTWQANodesLinkedList
    extends QANodesLinkedList
    implements java.io.Serializable, java.lang.Cloneable {
	public VRPTWQANodesLinkedList() {
	}
}
