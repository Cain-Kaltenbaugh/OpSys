VRPTW

Aaron Wecekerly
Marc Sensenich
Eric McAlpine

To change the files in which the VRPTW problem is chosen from, the function within VRPTWRoot
on line 37 may be changed to include any of the excel files found within the folder located 
at X:\CPSC-464-01.0914\Group Projects\Group 4 - VRP with Time Windows\Dr Sam VRPTW Workspace\
Zeus\data\VRPTW\ExcelDataFiles

Upon completion of the program, a Results file will be located in at location:
X:\CPSC-464-01.0914\Group Projects\Group 4 - VRP with Time Windows\Dr Sam VRPTW Workspace\
Zeus\data\VRPTW\Results

Currently the Quality Assurance package for VRPTW is not called within the program and is
under construction
